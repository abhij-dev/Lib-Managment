package com.libManag.LibraryManagement.service;

import java.util.ArrayList;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Service;
import com.libManag.LibraryManagement.Model.Book;
import com.libManag.LibraryManagement.Model.Department;
import com.libManag.LibraryManagement.repository.BookRepository;
import com.libManag.LibraryManagement.repository.DepartmentRepository;

@Service
public class LibraryService {

    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private DepartmentRepository departmentRepository;
    
    public ResponseEntity<String> addBook(Book book) {

    	//checking valid department or not
        if (book.getDepartment() != null && book.getDepartment().getId() != 0) {
            Department department = departmentRepository.findById(book.getDepartment().getId()).orElse(null);
            
            if (department == null) {
                return ResponseEntity.ok("Invalid Department ID");
            } else {
                book.setDepartment(department);
                bookRepository.save(book);
                return ResponseEntity.ok("Book added successfully");
            }
        } else {
            return ResponseEntity.ok("Department ID is required");
        }
    }


    
    

    public void removeBook(String ISBN) {
        Book book = bookRepository.findByISBN(ISBN);
        if (book != null) {
            bookRepository.delete(book);
        }
    }

    public List<Book> findBookByTitle(String title) {
        List<Book> books = bookRepository.findAll();
        List<Book> matchedBooks = new ArrayList<>();
        
        for (Book bo : books) {
            if (bo.getTitle().equalsIgnoreCase(title)) {
                matchedBooks.add(bo);
            }
        }
        
        return matchedBooks;
    }


    public List<Book> findBookByAuthor(String author) {
        List<Book> books = bookRepository.findAll();
        List<Book> matchedBooks = new ArrayList<>();
        
        for (Book bo : books) {
            if (bo.getAuthor().equalsIgnoreCase(author)) {
                matchedBooks.add(bo);
            }
        }
        
        return matchedBooks;
    }

    public List<Book> listAllBooks() {
        return bookRepository.findAll();
    }

    public List<Book> listAvailableBooks() {
        return bookRepository.findByAvailability(true);
    }
}
