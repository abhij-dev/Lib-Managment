package com.libManag.LibraryManagement.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.libManag.LibraryManagement.Model.Book;

public interface BookRepository extends JpaRepository<Book, Integer> {
    List<Book> findByTitleIgnoreCase(String title);
    
    List<Book> findByAuthorIgnoreCase(String author);
    
    List<Book> findByAvailability(boolean availability);
    
    List<Book> findAll();
    Book findByISBN(String ISBN);
}
