package com.libManag.LibraryManagement.Controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.libManag.LibraryManagement.Model.Book;
import com.libManag.LibraryManagement.service.LibraryService;

@RestController
@RequestMapping("/lib")
public class LibraryController {

	@Autowired
    private LibraryService libraryService;

    @PostMapping("/addBook")
    public ResponseEntity<String> addBook(@RequestBody Book book) {        
        List<Book> books = libraryService.listAllBooks();
        for (Book bo : books) {
            if (bo.getISBN().equals(book.getISBN())) {
                return ResponseEntity.ok("Book Already Exists");
            }
        }
        return libraryService.addBook(book);
    }

    @DeleteMapping("/removeBook/{ISBN}")
    public ResponseEntity<String> removeBook(@PathVariable String ISBN) {
        List<Book> books = libraryService.listAllBooks();
        
        for (Book bo : books) {
            if (bo.getISBN().equals(ISBN)) {
                libraryService.removeBook(ISBN);
                return ResponseEntity.ok("Book Deleted successfully");
            }
        }
        
        return ResponseEntity.ok("Book Not Found!");
    }


    @GetMapping("/findBookByTitle/{title}")
    public ResponseEntity<?> findBookByTitle(@PathVariable String title) {
        List<Book> books = libraryService.findBookByTitle(title);
        
        if (books.isEmpty()) {
            return ResponseEntity.ok("Book Not Found! ");
        } else {
            return ResponseEntity.ok(books);
        }
    }


    @GetMapping("/findBookByAuthor/{author}")
    public ResponseEntity<?> findBookByAuthor(@PathVariable String author) {
        List<Book> books = libraryService.findBookByAuthor(author);
        
        if (books.isEmpty()) {
            return ResponseEntity.ok("Book Not Found! ");
        } else {
            return ResponseEntity.ok(books);
        }
    }

    @GetMapping("/listAllBooks")
    public List<Book> listAllBooks() {
        return libraryService.listAllBooks();
    }

    @GetMapping("/listAvailableBooks")
    public List<Book> listAvailableBooks() {
        return libraryService.listAvailableBooks();
    }
}
