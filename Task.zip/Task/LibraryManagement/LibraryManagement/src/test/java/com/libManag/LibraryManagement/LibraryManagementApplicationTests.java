package com.libManag.LibraryManagement;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.ArgumentMatchers.anyInt;
import static org.mockito.Mockito.never;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.verify;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.MockitoAnnotations;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.ResponseEntity;

import com.libManag.LibraryManagement.Model.Book;
import com.libManag.LibraryManagement.Model.Department;
import com.libManag.LibraryManagement.repository.BookRepository;
import com.libManag.LibraryManagement.repository.DepartmentRepository;
import com.libManag.LibraryManagement.service.LibraryService;

@SpringBootTest
class LibraryManagementApplicationTests {
	
	@Mock
    private BookRepository bookRepository;

    @Mock
    private DepartmentRepository departmentRepository;

    @InjectMocks
    private LibraryService libraryService;

    @BeforeEach
    public void setUp() {
        MockitoAnnotations.openMocks(this);
    }

    @Test
    public void testAddBook_ValidDepartment() {
    	List<Book> books = new ArrayList<>();
        Department department = new Department(1, "IT", books);
        Book book = new Book(1, "Test Book", "Test Author", "1234567890", "Test Genre", 2023, true, department);

        when(departmentRepository.findById(1)).thenReturn(Optional.of(department));
        when(bookRepository.save(any(Book.class))).thenReturn(book);

        ResponseEntity<String> response = libraryService.addBook(book);

        assertEquals("Book added successfully", response.getBody());
        verify(departmentRepository, times(1)).findById(1);
        verify(bookRepository, times(1)).save(any(Book.class));
    }

    @Test
    public void testAddBook_InvalidDepartment() {
        Book book = new Book();
        List<Book> books = new ArrayList<>();
        book.setDepartment(new Department(2, "IT", books)); // Assuming department with ID 2 does not exist

        when(departmentRepository.findById(2)).thenReturn(Optional.empty());

        ResponseEntity<String> response = libraryService.addBook(book);

        assertEquals("Invalid Department ID", response.getBody());
        verify(departmentRepository, times(1)).findById(2);
        verify(bookRepository, never()).save(any(Book.class));
    }

    @Test
    public void testAddBook_NoDepartmentId() {
        Book book = new Book(); // Assuming no department ID is set

        ResponseEntity<String> response = libraryService.addBook(book);

        assertEquals("Department ID is required", response.getBody());
        verify(departmentRepository, never()).findById(anyInt());
        verify(bookRepository, never()).save(any(Book.class));
    }

    @Test
    public void testRemoveBook() {
        String isbn = "1234567890";
        List<Book> books = new ArrayList<>();
        Book book = new Book(1, "Test Book", "Test Author", isbn, "Test Genre", 2023, true, new Department(1, "IT",books));

        when(bookRepository.findByISBN(isbn)).thenReturn(book);

        libraryService.removeBook(isbn);

        verify(bookRepository, times(1)).delete(book);
    }

    @Test
    public void testFindBookByTitle() {
        String title = "Test Book";
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, title, "Test Author", "1234567890", "Test Genre", 2023, true, new Department(1, "IT", books)));

        when(bookRepository.findAll()).thenReturn(books);

        List<Book> result = libraryService.findBookByTitle(title);

        assertEquals(1, result.size());
        assertEquals(title, result.get(0).getTitle());
    }

    @Test
    public void testFindBookByAuthor() {
        String author = "Test Author";
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "Test Book", author, "1234567890", "Test Genre", 2023, true, new Department(1, "IT", books)));

        when(bookRepository.findAll()).thenReturn(books);

        List<Book> result = libraryService.findBookByAuthor(author);

        assertEquals(1, result.size());
        assertEquals(author, result.get(0).getAuthor());
    }

    @Test
    public void testListAllBooks() {
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "Test Book", "Test Author", "1234567890", "Test Genre", 2023, true, new Department(1, "IT", books)));

        when(bookRepository.findAll()).thenReturn(books);

        List<Book> result = libraryService.listAllBooks();

        assertEquals(1, result.size());
    }

    @Test
    public void testListAvailableBooks() {
        List<Book> books = new ArrayList<>();
        books.add(new Book(1, "Test Book", "Test Author", "1234567890", "Test Genre", 2023, true, new Department(1, "IT", books)));

        when(bookRepository.findByAvailability(true)).thenReturn(books);

        List<Book> result = libraryService.listAvailableBooks();

        assertEquals(1, result.size());
        assertEquals(true, result.get(0).isAvailability());
    }

}
